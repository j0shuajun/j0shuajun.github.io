---
name: para-organize
description: Internal organizing worker for para-curate that moves written clip notes into final PARA resource paths, preserves immutable Original Content, enforces digest link integrity, and returns final note and digest paths for qa-final.
---

# PARA Organize (Internal)

## Overview

Use this skill only when orchestrated by `para-curate`.
Do not ask users to invoke this skill directly.

Goal:

- move one written clip note to final resource location
- relocate related assets
- update digest with final-note-only success links
- preserve immutable Original Content and exact-equal link-item rule
- return finalization paths for qa-final

## Execution Principles (AGENTS-Aligned)

1. Think before organize: resolve type/subfolder by evidence first, not by guess.
2. Ambiguity handling: when classification is unclear, fallback to bucket root and return explicit reason.
3. Simplicity first: perform only move/classify/digest operations defined in this contract.
4. Surgical changes: never rewrite semantic body content during organize.
5. Goal-driven verification: pass pre/post integrity checks before success return.

## Input

Required input:

- absolute `note_path` to markdown note in `/path/to/your/vault/00-inbox/clips`

Preconditions:

1. matching done pack exists in `draft/done` with `[yymmdd] <title>_draft.md`
2. matching pending pack is absent from `draft/pending_write`
3. done and pending draft names keep single `_draft` suffix

Integrity preconditions from done pack:

- `original_content_hash_sha256`
- `original_content_url_list`
- `original_content_source`
- `original_content_line_count`

If preconditions fail, skip organize and return explicit reason.

## Output Contract (Mandatory)

Return:

```text
status: success|fail
reason: <reason_code|empty>
final_note_path: <abs path under 30-resource/*> # required on success
digest_path: <abs path>                         # required on success
digest_updated: true|false                      # required on success
```

On success, set `digest_updated: true`.
Use checklist-based decisions only.
Do not use numeric confidence/score thresholds.

## Classification Rule

Determine `source_type` from done-pack evidence first.
If unavailable, infer from note content.

Priority when overlap exists:

1. Article
2. Paper
3. Repo
4. Scrap

Move note to exactly one bucket:

- `/path/to/your/vault/30-resource/31-Article`
- `/path/to/your/vault/30-resource/32-Paper`
- `/path/to/your/vault/30-resource/33-Repo`
- `/path/to/your/vault/30-resource/34-Scrap`

## Subfolder Placement Policy

Default destination is bucket root.
Create a new relevant subfolder when no relevant existing subfolder exists and theme evidence is clear.

Constraints:

1. never place note into unrelated subfolder
2. if exact existing theme match exists, use it
3. if no relevant subfolder exists and one clear theme exists, create new subfolder
4. if ambiguous, fallback to bucket root

Theme selection precedence:

1. `taxonomy_hints` from done pack
2. canonical theme tags in frontmatter
3. normalized title phrase resolved by alias baseline

Candidate validity:

1. must match `^[a-z]+(-[a-z]+)?$`
2. must be supported by title/tags/hints
3. must not conflict across evidence sources

If candidate invalid or conflicting, fallback bucket root and return:

- `subfolder_creation_required`

## Frontmatter Integrity Rule

Before and after move:

1. `title` must be double-quoted YAML string
2. `category` must be `30-resource`
3. `tags` must be YAML list
4. `link` must be YAML list
5. each tag must match `^[a-z]+(-[a-z]+)?$`
6. each `link` item must be either:
   - absolute `http://` or `https://` URL
   - vault-relative asset path `99-meta/assets/<filename>`

Normalize when fixable, except `link` values.
If parsing still fails, return `yaml_parse_error`.

## Original Content and Link Preservation (Mandatory)

Organize is move/classify stage, not content rewrite stage.

Rules:

1. do not modify `# Original Content` block
2. do not modify frontmatter `link` values
3. do not add, remove, reorder, or normalize immutable-zone bytes
4. do not canonicalize link URLs
5. if `# Original Content` heading is missing, fail `original_content_missing`
6. if immutable zone contains Obsidian wikilink (`[[...]]` or `![[...]]`), fail `original_content_contains_wikilink`
7. if any frontmatter link item is neither URL nor `99-meta/assets/...`, fail `link_contains_non_url`
8. if frontmatter link list is not exact-equal to immutable-zone link-item list, fail `link_not_equal_original_content`
9. if immutable-zone hash differs from done-pack hash, fail `original_content_modified`

## Asset Relocation Rule

After note move, relocate associated binaries:

- primary destination: `/path/to/your/vault/99-meta/assets`
- ambiguous ownership: `/path/to/your/vault/99-meta/assets/_shared-review`

Update note references to relocated assets.
Never write relocated local paths into frontmatter `link`.
When representing relocated assets, use plain vault-relative path `99-meta/assets/...`.

## Organize Self-Checks (Pre and Post Move)

Run same integrity checks before and after move:

1. immutable-zone hash matches done-pack `original_content_hash_sha256`
2. frontmatter link list equals done-pack `original_content_url_list`
3. frontmatter link list equals link-item list extracted from immutable zone

If any check fails, return one of:

- `original_content_missing`
- `original_content_contains_wikilink`
- `original_content_modified`
- `link_not_equal_original_content`
- `link_contains_non_url`

## Digest Update Rule

Update or create:

- `/path/to/your/vault/99-meta/digests/YYYY-MM-DD.md`

Maintain section order:

1. `# Articles`
2. `# Papers`
3. `# Repos`
4. `# Scrap`
5. `# Errors`

Success entry format must stay exact:

```text
1. [[[yymmdd] <title>]]
    Summary: ...
    Keywords: ...
```

Success-link constraints:

1. write success entry only after move completes
2. syntax must be exactly `N. [[[yymmdd] <title>]]`
3. resolve success link only under `30-resource/*`
4. never target draft folders as success link destination
5. fail with `digest_link_malformed` for invalid syntax
6. fail with `digest_points_to_draft` when draft path appears
7. if final target unresolved, skip success entry and return `digest_target_missing`
8. if multiple final candidates match title, fail `digest_link_ambiguous`
9. if any draft pack naming violates suffix rule, fail `draft_pack_name_invalid`

Error entry format under `# Errors`:

```text
- stage: <extract|write|qa-note|organize|qa-final|finalize>
  target: <title or filename>
  reason: <machine-readable reason code>
```

## Failure Behavior

On failure:

1. avoid partial finalization state
2. do not emit invalid success links
3. return explicit reason code

Recommended reason codes:

- `yaml_parse_error`
- `digest_points_to_draft`
- `digest_target_missing`
- `digest_link_ambiguous`
- `digest_link_malformed`
- `draft_pack_name_invalid`
- `subfolder_irrelevant`
- `subfolder_creation_required`
- `original_content_missing`
- `original_content_contains_wikilink`
- `original_content_modified`
- `link_not_equal_original_content`
- `link_contains_non_url`

## Idempotency

1. rerun must not duplicate digest success entries
2. rerun must not duplicate asset moves
3. preserve user-authored text outside managed blocks
4. preserve immutable-zone bytes exactly
