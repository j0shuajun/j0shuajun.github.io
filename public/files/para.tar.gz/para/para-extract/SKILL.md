---
name: para-extract
description: Internal extraction worker for para-curate that reads one clip source and creates or refreshes exactly one pending Evidence Pack with checklist-based sufficiency gates, structured Paper evidence blocks, and explicit return payload fields.
---

# PARA Extract (Internal)

## Overview

Use this skill only when orchestrated by `para-curate`.
Do not ask users to invoke this skill directly.

Goal:

* read one clip source
* build or refresh one Evidence Pack in pending state
* return deterministic machine-readable outputs for next-stage routing

## Execution Principles (AGENTS-Aligned)

1. Think before extraction: when source signals conflict, avoid silent over-interpretation.
2. Ambiguity handling: prefer minimal assumptions and record insufficiency through `needs_more_extraction` + `extraction_gap`.
3. Simplicity first: extract only evidence needed for required-section depth and traceability.
4. Surgical scope: modify only one target pending pack; never rewrite source clip content.
5. Goal-driven verification: return `success` only after mandatory fields and depth inputs pass checklist.

## Input

Required input:

* absolute clip path under `/path/to/your/vault/00-inbox/clips`

Accepted source forms:

* markdown clip note
* PDF/image/binary clip file

Optional input:

* `depth_profile: balanced-deep-kr-v1` (default)

## Output Contract (Mandatory)

Return:

```text
status: success|fail
reason: <reason_code|empty>
evidence_pack_path: <abs path in pending_write> # required on success
inbox_pointer: <abs path in 00-inbox/clips>     # required on success
source_type: Article|Paper|Repo|Scrap           # optional when uncertain
article_profile: narrative|docs_reference        # optional; Article only
```

Use checklist-based yes/no gating.
Do not output or persist numeric trust values (`confidence`, `score`, `threshold`, `%`, `0~1`).

## Evidence Pack Path and Naming

Create or refresh exactly one pack:

* `/path/to/your/vault/99-meta/draft/pending_write/[yymmdd] <title>_draft.md`

Naming rules:

1. append `_draft` exactly once
2. never produce `_draft_draft`
3. refresh in place when retrying the same target

## Evidence Pack Base Structure

Do not add frontmatter.
Do not write Korean narrative prose in pack body outside Summary Kit.
Pack body is primarily structured evidence.

Use this top-level structure:

```text
source_type: Article|Paper|Repo|Scrap
article_profile: narrative|docs_reference   # optional; Article only
source_path: <absolute path if local source>
source_url: <url if url-based source>
proposed_title: <official source title>
inbox_pointer: <absolute path in 00-inbox/clips>
taxonomy_hints: [<optional slug>, ...]
depth_contract_version: balanced-deep-kr-v1
depth_inputs:
  required_sections: [<section_name>, ...]
  key_detail_trace:
    - key_detail_id: <stable id>
      headline: <text>
      support_locator: <text>
      evidence_snippet: <text>
needs_more_extraction: <true|false>   # optional
extraction_gap: [<missing_block_name>, ...]  # optional

## Summary Kit
...

## Evidence
...
```

`source_path` or `source_url` must exist.
If both exist, include both.

## Summary Kit (Mandatory for Article/Repo/Paper when evidence exists)

Purpose:

* Provide “write-ready” materials for easy Korean summary without forcing bullet counts.

Rules:

* Do not force a fixed number of points.
* Stop adding details when they become redundant or cannot be grounded.
* Each `key_details` item must be traceable to a locator or a faithful excerpt/paraphrase.

Template:

```text
## Summary Kit
one_liner: <한 문장 정의 (근거 가능해야 함)>
why_it_matters: <왜 중요한가 / 기존 대비 차이>
key_details:
  - key_detail_id: KD1
    headline: <짧은 제목>
    gist: <짧은 설명>
    support_locator: <section/page/figure/table/file/README heading 등>
    evidence_snippet: <25단어 이내 인용 또는 충실한 요약>
use_when: <언제 쓰면 좋은가 (있으면)>
avoid_when: <언제 피하면 좋은가 / 전제조건 (있으면)>
quickstart:
  - <설치/실행/사용 최소 루트(원문에 있으면)>
gotchas:
  - <제약/리스크/주의사항(원문에 있으면)>
representative_figure:
  file: <abs path>                    # optional
  figure_id: <Figure N | "Hero image"># optional
  page: <pdf page number>             # optional when pdf
  caption: <faithful caption/summary>
  why_meaningful: <why it matters>
  selection_reason: <why chosen>
```

Notes:

* `representative_figure` is optional for Article/Repo; required for Paper only when a meaningful figure exists and can be extracted.
* Never fabricate `quickstart` if it does not exist; instead leave empty and reflect missingness in evidence.

Depth input requirements:

1. `key_detail_trace` must be generated from `Summary Kit.key_details` in the same order.
2. `key_detail_id` must be stable (`KD1`, `KD2`, ...) within one pack.
3. each trace item must keep `support_locator` and `evidence_snippet` non-empty.
4. if trace cannot be built, set `needs_more_extraction: true` and add `extraction_gap`.

## Required Sections by Source Type (`depth_inputs.required_sections`)

Set deterministic required section labels:

1. Repo: `문제정의`, `구조/메커니즘`, `실행/운영`, `적용`, `리스크`
2. Article (`article_profile: narrative`): `주장`, `작동 원리`, `사례/근거`, `적용`, `한계`
3. Article (`article_profile: docs_reference`): `문서 성격과 범위`, `기능 구조`, `구현 시 확인할 근거`, `적용`, `한계`
4. Scrap: `관측 사실`, `해석 경계`, `적용 포인트`, `주의`
5. Paper: keep existing mandatory paper evidence blocks and claim-support mapping

## Link Source Boundary (Mandatory)

Evidence links collected by extract are reference evidence only.

Rules:

1. extract may store source URLs, PDF links, code links, and project links inside Evidence Pack
2. extract must not define or infer final frontmatter `link` values
3. frontmatter `link` single source of truth is ordered link items in `# Original Content` in note
4. canonical expansion decisions must not be made in extract

## Title Rules

`proposed_title` rules:

1. preserve original source semantics and special characters
2. do not apply destructive normalization
3. for `source_type: Paper`, remove arXiv bracket prefix from title

Paper title normalization example:

* forbidden: `[2510.12345] Paper Title`
* required: `Paper Title`

## Source Type Priority

When signals overlap, classify in this order:

1. Article
2. Paper
3. Repo
4. Scrap

## Evidence Requirements by Type

### Article

Include (as available from source):

1. heading map (H1-H3)
2. key claims with grounded supporting excerpts
3. examples, code, table mentions
4. assumptions, limits, prerequisites
5. any “what to do next” or operational implications (when present)

Article profile routing:

1. `article_profile: docs_reference` when source is primarily official docs/reference/tutorial/API parameter guide
2. otherwise `article_profile: narrative`

Depth contract note:

* For `article_profile: narrative`, evidence must support:
  * `주장`
  * `작동 원리`
  * `사례/근거`
  * `적용`
  * `한계`
* For `article_profile: docs_reference`, evidence must support:
  * `문서 성격과 범위`
  * `기능 구조`
  * `구현 시 확인할 근거`
  * `적용`
  * `한계`

### Repo

Include:

1. README title and one-line purpose
2. install and usage steps (if present)
3. runnable examples (if present)
4. top-level directory map (if visible)
5. key config highlights (if present)
6. extension points (if present)
7. maturity signals from repository context (release/CI/docs/maintenance notes if present)

Depth contract note:

* Evidence must be sufficient to support required sections:
  * `문제정의`
  * `구조/메커니즘`
  * `실행/운영`
  * `적용`
  * `리스크`

### Scrap

Include:

1. OCR transcript
2. speaker or subject split when inferable
3. source context
4. missing-context and verification gaps

Depth contract note:

* Evidence must be sufficient to support required sections:
  * `관측 사실`
  * `해석 경계`
  * `적용 포인트`
  * `주의`

### Paper (Mandatory Structured Blocks)

Under `## Evidence`, include these blocks when `source_type: Paper`:

1. `Bibliography`

* `title`, `authors`, `venue_or_journal`, `year` (when available)
* `identifiers` (arXiv, DOI, etc.)
* `links` (PDF, project, code)

2. `Problem & Contributions`

* `problem_statement` (short, clear, faithful)
* `contributions` (list)
* `claim_cards` (required structured cards)

3. `Method`

* `method_overview`
* `key_components`
* `algorithm_or_procedure` (when available)
* `key_equations` (equation id, definition, meaning)

4. `Experimental Setup`

* `datasets`
* `baselines`
* `metrics`
* `protocol`
* `implementation_details` (only explicitly stated facts)
* `compute_and_efficiency` (when available)

5. `Results`

* `main_results` with original numeric values and comparison context
* include table or figure locators for result evidence
* `ablation_or_analysis` (when available)
* `failure_cases` (when available)
* `stat_tests_or_significance` (when available)

6. `Limitations & Discussion`

* `limitations`
* `assumptions`
* `threats_to_validity` (when available)

7. `Reproducibility`

* `released_code_or_data` (when available)
* `missing_details` (reproducibility gaps)

## Paper Claim Card (Mandatory)

Use this structure:

```text
claim_cards:
  - id: C1
    claim: <single-sentence claim>
    support:
      - type: table|figure|equation|text
        locator: <section/page/figure/table id>
        excerpt_or_paraphrase: <quote up to 25 words or faithful paraphrase>
        why_supports: <why this support is valid>
```

Do not include confidence scores or thresholds in claim cards.

## Figure Quality Gate (Mandatory)

Accept only meaningful figures:

* method diagram
* architecture figure
* core result plot
* key comparison chart
* ablation chart

Reject:

1. full-page screenshot without figure focus
2. abstract or intro text pages captured as image
3. decorative or emoticon-only visual
4. blank or near-empty image
5. cover page, references page, irrelevant appendix visual

For paper PDF inputs:

* select one representative meaningful figure when feasible
* crop to figure region (not full page)
* save to `/path/to/your/vault/99-meta/assets/[yymmdd] <title>_figure1.png`
* keep readability and trim unnecessary whitespace
* record full metadata in `representative_figure`

## Paper Sufficiency Gate (Checklist, No Numeric Threshold)

If any mandatory Paper item is missing, set:

* `needs_more_extraction: true`
* `extraction_gap: [<missing_block_name>, ...]`

Mandatory checklist:

1. contributions list exists
2. method key components exist
3. experimental setup is structured for available evidence
4. `main_results` includes at least one original numeric result and locator
5. limitations or discussion summary exists (if present in source)
6. representative figure metadata is complete when figure is extractable

When downgraded:

1. keep pack in `pending_write`
2. do not fabricate missing evidence

## Failure Behavior

On failure:

1. do not modify source clip
2. do not create malformed pack
3. return explicit `status: fail` and `reason`

Recommended reason codes:

* `needs_more_extraction`
* `figure_not_meaningful`
* `figure_metadata_missing`

## Idempotency

1. refresh existing pending pack in place when target matches
2. preserve deterministic filename `[yymmdd] <title>_draft.md`
3. preserve still-valid existing fields during refresh
