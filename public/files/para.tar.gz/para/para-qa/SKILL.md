---
name: para-qa
description: Internal QA validator for para-curate that runs qa-note and qa-final checklists, performs hash-strict Original Content integrity checks, validates exact-equal link-item rules, and returns reason-coded retry routes plus diagnostics.
---

# PARA QA (Internal)

## Overview

Use this skill only when orchestrated by `para-curate`.
Do not ask users to invoke this skill directly.

Goal:

* validate note and finalization gates after write and organize
* enforce hash-strict Original Content integrity
* enforce exact-equal link-item policy against Original Content
* validate “easy-kr-v1” readability requirements without fixed-count forcing
* return deterministic pass/fail and retry routing

## Execution Principles (AGENTS-Aligned)

1. Think before judgment: when evidence is unclear, fail with diagnostics instead of silent pass.
2. Ambiguity handling: expose uncertainty through reason codes and missing-item diagnostics.
3. Simplicity first: keep decisions checklist-based yes/no without numeric scoring.
4. Surgical auto-fix: limit fixes to declared YAML/frontmatter shape scope only.
5. Goal-driven verification: emit deterministic `retry_stage` aligned to failed gates.

## Modes

### `qa-note`

Run immediately after write.
Validate note-level structure, evidence reflection depth, Summary Kit reflection, and immutable-zone integrity.

### `qa-final`

Run immediately after organize.
Re-validate immutable-zone integrity, link equality, digest links, final-note location, draft naming, and final report sections/language.

## Input Contract

Expected inputs:

1. `mode`: `qa-note` or `qa-final`
2. `note_path`: absolute markdown note path
3. `evidence_pack_path`: absolute done-pack path when available
4. `digest_path`: current digest path for `qa-final`
5. `final_report_text`: required for `qa-final`
6. `style_profile`: optional, default `easy-kr-v1`
7. `depth_profile`: optional, default `balanced-deep-kr-v1`
8. `action`: optional `auto_fix`

`evidence_pack_path` for integrity checks must contain:

* `original_content_hash_sha256`
* `original_content_url_list`
* `original_content_source`
* `original_content_line_count`

## Output Contract (Mandatory)

Return:

```text
status: pass|fail
reasons: [<reason_code>, ...]
auto_fixed_fields: [<field_name>, ...]
retry_stage: write|organize|none
diagnostics:
  missing_sections: [<section_name>, ...]
  missing_evidence_items: [<item_name>, ...]
  missing_depth_units: [<section_or_unit_id>, ...]
  unlinked_claims: [<snippet>, ...]
  unmapped_key_details: [<key_detail_id>, ...]
  key_detail_id_occurrences: [<location_or_snippet>, ...]
  moc_issues: [<issue_or_snippet>, ...]
  marker_occurrences: [<location_or_snippet>, ...]
  link_mismatch_added: [<link_item>, ...]
  link_mismatch_missing: [<link_item>, ...]
  link_order_or_count_mismatch: true|false
  original_content_hash_mismatch: true|false
  unsubstantiated_claims: [<snippet>, ...]
  redundant_points: [<snippet>, ...]
  missing_summary_kit_fields: [<field_name>, ...]
```

Use checklist-based yes/no decisions.
Do not output numeric confidence or threshold metrics.

## YAML and Frontmatter Checklist

Validate:

1. frontmatter parses
2. `title` is double-quoted YAML string
3. `category` is exactly `30-resource`
4. `tags` is YAML list
5. each tag matches `^[a-z]+(-[a-z]+)?$`
6. `link` is YAML list
7. each `link` item is either absolute `http://` or `https://` URL, or vault-relative asset path `99-meta/assets/<filename>`

Reason codes:

* `yaml_parse_error`
* `title_not_quoted`
* `category_not_30_resource`
* `tags_not_yaml_list`
* `tags_invalid_format`
* `link_not_yaml_list`
* `link_contains_non_url`
* `moc_invalid_shape`
* `key_detail_id_exposed`

Auto-fix scope (`action=auto_fix`) is limited to:

1. title quoting and escaping
2. category normalization to `30-resource`
3. tags list normalization and tag format normalization
4. link list shape normalization only (not link value edits)

Forbidden auto-fix actions:

1. modifying `# Original Content` block
2. editing frontmatter link values to force pass
3. semantic rewriting of note body
4. rewriting Summary Kit-derived content

## Original Content Hash-Strict Checklist (`qa-note`, `qa-final`)

Anchor:

* first `# Original Content` heading in note

Immutable zone:

* from anchor line to EOF (inclusive)

Validation:

1. if anchor missing, fail with `original_content_missing`
2. if immutable zone contains Obsidian wikilink (`[[...]]` or `![[...]]`), fail `original_content_contains_wikilink`
3. compute SHA-256 over immutable-zone bytes
4. compare with `original_content_hash_sha256` from done pack
5. if different, set `diagnostics.original_content_hash_mismatch: true` and fail `original_content_modified`
6. if same, set `diagnostics.original_content_hash_mismatch: false`

## `link` Exact-Equal Checklist (`qa-note`, `qa-final`)

Validation source:

* literal link-item list extracted from immutable zone only

Comparison rule:

1. compare frontmatter `link` with immutable-zone link-item list by literal string
2. canonicalization is forbidden
3. URL/path equivalence guessing is forbidden
4. order and count must match exactly

Failure behavior:

1. if any frontmatter link item is neither URL nor `99-meta/assets/...`, fail `link_contains_non_url`
2. if lists are not exact-equal, fail `link_not_equal_original_content`
3. fill diagnostics:

* `link_mismatch_added`: link items only in frontmatter link
* `link_mismatch_missing`: link items missing from frontmatter link
* `link_order_or_count_mismatch`: true when order/count differs

## Marker Text Checklist (`qa-note`)

Validate note body does not contain:
`para-curate:stage=written`

If found:

* add `marker_text_present` to reasons
* append marker locations/snippets to `diagnostics.marker_occurrences`

## MoC Shape Checklist (`qa-note`)

Validate `## 🧭 MoC` section shape:

1. section exists exactly once
2. content uses Markdown bullet list (line starts with `- `)
3. no pseudo-YAML key text like `unresolved_links:`
4. when no resolvable MoC links exist, allow exact fallback bullet `- 아직 연결된 MoC 없음`

If violated:

* add `moc_invalid_shape`
* append issues/snippets to `diagnostics.moc_issues`

## Key Detail ID Exposure Checklist (`qa-note`)

`key_detail_id` mapping is required semantically, but ID tokens must stay internal.

Validate:

1. note body does not expose literal tokens such as `KD1`, `KD2`, ...

If found:

* add `key_detail_id_exposed`
* append occurrences to `diagnostics.key_detail_id_occurrences`

## Summary Kit Reflection Checklist (`qa-note`, easy-kr-v1)

Purpose:

* Ensure the “예시처럼 쉽고 일목요연한” summary exists without forcing counts.

Checklist (yes/no; no fixed counts):

1. `> [!summary]` exists
2. Summary contains a faithful `one_liner` reflection (or equivalent)
3. Summary contains a faithful `why_it_matters` reflection (or equivalent)
4. Summary reflects `key_details` in a scannable manner (bullets/numbering allowed when natural)
5. If `quickstart` exists in Summary Kit, it appears in summary or notes (missing => fail)
6. If `gotchas` exists in Summary Kit, it appears in summary or notes (missing => soft warning; fail only if it causes shallow overall)
7. every `key_detail_id` in `depth_inputs.key_detail_trace` is mapped in summary/notes

Failure mapping:

* If any critical items missing or summary becomes generic: add `notes_too_shallow`
* Populate diagnostics:

  * `missing_summary_kit_fields`
  * `unmapped_key_details`
  * `unsubstantiated_claims`
  * `redundant_points`

## Depth Unit Completeness Checklist (`qa-note`, balanced-deep-kr-v1)

Purpose:

* separate style quality from evidence depth quality
* block shallow notes even when sections exist

Depth Unit definition:

1. `claim`
2. `support_locator` or `evidence_snippet`
3. `implication` or `limitation`

Validation:

1. load `depth_inputs.required_sections` from evidence pack
2. for each required section, verify at least one valid depth unit exists
3. if strong claim text appears without support locator/snippet, flag `unlinked_claims`
4. if any required section lacks depth unit, add item to `missing_depth_units`
5. if any `key_detail_id` is missing in note reflection, add item to `unmapped_key_details`

Failure mapping (hard-gating):

1. non-empty `missing_depth_units` -> `notes_too_shallow`
2. non-empty `unlinked_claims` -> `notes_too_shallow`
3. non-empty `unmapped_key_details` -> `notes_too_shallow`

Retry handoff contract:

* when `retry_stage: write`, pass these diagnostics as `repair_directives` to write retry:
  * `missing_depth_units`
  * `unlinked_claims`
  * `unmapped_key_details`

## Source-Grounded Depth Checklist (`qa-note`)

Do not use fixed-count quotas.
Validate note content against Evidence Pack.

Generic fail triggers:

1. major evidence claims are missing in note
2. key assumptions/conditions are missing
3. key results or figures are omitted when present in evidence
4. note content is generic and not evidence-traceable
5. required sections exist but depth units are absent
6. key detail trace is not fully mapped

Fail reason:

* `notes_too_shallow`

Populate diagnostics with missing items.

## Paper Depth Checklist (`qa-note`, Mandatory)

When `source_type: Paper`, verify reflection of Evidence Pack items when present:

* `contributions`
* method key components
* experimental setup
* `main_results` with original numeric values
* limitations
* claim-card mapping (`claim -> support locator`)

If missing:

1. add `notes_too_shallow`
2. fill `diagnostics.missing_sections`
3. fill `diagnostics.missing_evidence_items`

## Paper Title Rule (`qa-note`)

For Paper, fail if title contains arXiv token (`2510.12345` or `[2510.12345]`):

* `paper_title_contains_arxiv_id`

## Figure Quality Checklist (`qa-note`)

Validate:

1. inserted figure is meaningful
2. figure metadata exists (`figure_id`, `page` when relevant, `caption`, `why_meaningful`, `selection_reason`)
3. figure is not a full-page text capture or decorative/blank visual

Reason codes:

* `figure_not_meaningful`
* `figure_metadata_missing`

## Digest and Finalization Checklist (`qa-final`)

Validate digest success entries:

1. each success line follows exact syntax `N. [[[yymmdd] <title>]]`
2. success links resolve only to final notes under `30-resource/*`
3. no success link points to pending or done draft folders
4. linked final note target is resolvable
5. each digest title resolves to exactly one final note candidate

Reason codes:

* `digest_link_malformed`
* `digest_points_to_draft`
* `digest_target_missing`
* `digest_link_ambiguous`
* `subfolder_irrelevant`
* `subfolder_creation_required`
* `draft_pack_name_invalid`

## Done-Pack Naming Checklist (`qa-final`)

Validate pending and done draft file names:

1. every draft markdown ends with `_draft.md`
2. `_draft` appears exactly once

Fail code:

* `draft_pack_name_invalid`

## Final Report Checklist (`qa-final`, easy-kr-v1)

`final_report_text` is mandatory input.

1. if missing or empty, fail `final_report_not_korean`
2. if provided text is not Korean, fail `final_report_not_korean`
3. required sections must exist (existence-only, no fixed counts):

   * `한 줄 정의`
   * `왜 중요한가`
   * `핵심 디테일`
   * `적용/바로 써보기`
   * `주의/한계`
4. if missing, add `final_report_not_korean` only when language is not Korean; otherwise treat as `notes_too_shallow`-style issue and set `retry_stage: organize` with diagnostics.missing_sections populated

## Retry Routing Rule

Set `retry_stage` deterministically:

1. YAML/title/tags/link/marker/notes/figure/paper-title/original-content/depth-unit failures in `qa-note` -> `write`
   * includes `moc_invalid_shape` and `key_detail_id_exposed`
2. digest/final-link/subfolder/draft-name/final-report/original-content failures in `qa-final` -> `organize`
3. no failure -> `none`

## Safety Rules

1. do not perform semantic body rewriting in QA
2. auto-fix is YAML/frontmatter shape only
3. do not auto-fix `link` values
4. do not auto-fix or rewrite immutable zone
5. depth and figure failures are not QA semantic fix targets
6. always return machine-readable reason codes and diagnostics
