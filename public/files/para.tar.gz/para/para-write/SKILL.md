---
name: para-write
description: Internal writing worker for para-curate that converts one pending Evidence Pack into a grounded note in clips, enforces immutable Original Content and exact-equal link-item rules, and returns note and done-pack paths.
---

# PARA Write (Internal)

## Overview

Use this skill only when orchestrated by `para-curate`.
Do not ask users to invoke this skill directly.

Goal:

* transform one pending Evidence Pack into one clip note
* enforce YAML and depth gates before moving pack to done
* enforce Original Content immutability and exact-equal link-item policy
* produce a readable Korean summary (style_profile: easy-kr-v1) without fixed-count forcing
* run two-stage writing (`draft generation` -> `depth overlay`) while preserving exemplar tone
* return machine-readable handoff paths for organize and QA

## Input

Required input:

* absolute path to one Evidence Pack in `/Users/joshua/Library/Mobile Documents/iCloud~md~obsidian/Documents/joshua/99-meta/draft/pending_write`
* pack filename must follow `[yymmdd] <title>_draft.md`

Optional input:

* `style_profile: easy-kr-v1` (default)
* `depth_profile: balanced-deep-kr-v1` (default)
* `repair_directives` (optional on retry):
  * `missing_depth_units: [<section_or_unit_id>, ...]`
  * `unlinked_claims: [<snippet>, ...]`
  * `unmapped_key_details: [<key_detail_id>, ...]`

Evidence Pack required fields:

* `source_type`
* `proposed_title`
* `inbox_pointer`
* `depth_contract_version`
* `depth_inputs`
* `## Summary Kit`
* `## Evidence`

Optional Evidence Pack field:

* `article_profile: narrative|docs_reference` (Article only)

## Execution Principles (AGENTS-Aligned)

1. Think before writing: do not convert uncertain evidence into definitive claims.
2. Ambiguity handling: prefer explicit unknown/limit wording or fail-path over speculation.
3. Simplicity first: keep output focused on required sections and evidence-backed details only.
4. Surgical edits: rewrite only managed sections and preserve unrelated user-authored content.
5. Goal-driven verification: finalize only after YAML, depth, and immutable/link self-checks pass.

## Output Contract (Mandatory)

Return:

```text
status: success|fail
reason: <reason_code|empty>
note_path: <abs path in 00-inbox/clips>             # required on success
done_pack_path: <abs path in 99-meta/draft/done>    # required on success
source_type: Article|Paper|Repo|Scrap               # optional
article_profile: narrative|docs_reference           # optional; Article only
title_yaml: <string>                                 # optional
file_title: <string>                                 # optional
depth_result: pass|fail                              # required on success
depth_missing_units: [<section_or_unit_id>, ...]    # required on success
```

Use checklist-based pass/fail only.
Do not use numeric confidence, scores, percentages, or thresholds.

## Hard Skip Gate

Do not write note content when:

1. `needs_more_extraction: true`
2. evidence is insufficient for deep writing

Skip behavior:

1. keep source note untouched
2. keep pack in `pending_write`
3. return `status: fail` with reason code

## `title` and `file_title` Rules

`title` (YAML display):

1. preserve original semantics from evidence as much as possible
2. apply only YAML escaping and double-quote requirements

`file_title` (filename-safe):

1. remove or replace `/ \\ : * ? " < > |`
2. trim leading and trailing whitespace
3. normalize repeated spaces when needed
4. truncate overlong names when needed (recommended within 120 chars)
5. preserve meaning as much as possible (prefer `_` or `-`)

## Target Note Resolution

1. if `inbox_pointer` points to existing markdown note in clips, update that note
2. if source is PDF/image/binary, create peer markdown note in clips as `[yymmdd] <file_title>.md`
3. never write outside:

* `/Users/joshua/Library/Mobile Documents/iCloud~md~obsidian/Documents/joshua/00-inbox/clips`
* `/Users/joshua/Library/Mobile Documents/iCloud~md~obsidian/Documents/joshua/99-meta`

## Frontmatter Properties Contract (Mandatory)

When creating or updating frontmatter, enforce schema and order:

1. `title`
2. `category`
3. `tags`
4. `created`
5. `updated`
6. `link`

Hard rules:

1. `title` is a double-quoted YAML string
2. escape inner double quotes as `\"`
3. `category` is exactly `30-resource`
4. `tags` is YAML list
5. each tag matches `^[a-z]+(-[a-z]+)?$`
6. `link` is YAML list
7. every `link` item must be either absolute `http://` or `https://` URL, or vault-relative asset path `99-meta/assets/<filename>`
8. if any `link` entry is neither URL nor `99-meta/assets/...`, fail with `link_contains_non_url`
9. if YAML parsing fails after normalization, fail with `yaml_parse_error`

## Original Content Immutable Zone (Mandatory)

Anchor:

* first `# Original Content` heading in the note

Immutable zone:

* from the anchor line to EOF (inclusive)

Rules:

1. for existing notes, immutable zone is byte-level immutable
2. do not reformat, reorder, trim, append, delete, or normalize any byte in immutable zone
3. if note is newly created and lacks anchor, create immutable zone exactly once
4. after first creation, treat immutable zone as immutable on every rerun
5. if existing note should have immutable zone but anchor is missing, fail with `original_content_missing`

## `link` Exact-Equal Rule (Mandatory)

Single source of truth:

* extract link items from immutable zone only

Exact-equal policy:

1. extract literal link items in encounter order from immutable zone
2. set frontmatter `link` to exactly that list
3. frontmatter `link` and extracted link-item list must match order and count exactly
4. canonicalization is forbidden
5. URL/path equivalence guessing is forbidden
6. literal string comparison only
7. if mismatch exists, fail with `link_not_equal_original_content`

## Original Content Asset Rendering Rule (Mandatory)

Inside `# Original Content`, render local assets as plain vault-relative path only.
Do not use Obsidian wikilink syntax (`[[...]]`, `![[...]]`) in immutable zone.
If wikilink syntax is present in immutable zone, fail with `original_content_contains_wikilink`.

## Marker Text Prohibition

Never generate this text in note body:

`<!-- para-curate:stage=written -->`

If this stale marker exists in managed content, remove it.

## Key Detail ID Rendering Rule

`key_detail_id` is for evidence-pack traceability, not user-facing note text.

Rules:

1. do not render literal identifiers like `KD1`, `KD2`, ... in note body
2. map each key detail semantically in summary/notes without exposing ID tokens
3. if ID tokens are present in body text, fail with `key_detail_id_exposed`

## Output Note Structure

Keep exactly one instance in this order:

1. `> [!summary]`
2. `## 🏷️ Keywords`
3. `## 🧭 MoC`
4. `## ❗️ Notes`
5. `## 🌐 Reference`
6. `---`
7. `# Original Content`

## Two-Stage Writing Pipeline (Mandatory)

Stage A: Exemplar-tone draft generation

1. generate natural Korean narrative using existing few-shot exemplars
2. keep style fluent and non-template-like
3. do not insert internal slot markers in output note

Stage B: Depth Overlay

1. evaluate each required section with depth units
2. if any section lacks required depth units, rewrite only missing parts
3. preserve already valid paragraphs and avoid whole-note rewrite
4. on retry with `repair_directives`, rewrite only directive-targeted deficits

Evidence-first priority:

1. if style and evidence-depth conflict, prioritize evidence-depth
2. readable tone remains required, but cannot override depth failures

## Depth Unit Contract (Mandatory)

Depth Unit definition:

1. `claim`
2. `support_locator` or `evidence_snippet`
3. `implication` or `limitation`

Pass rule:

1. section existence alone is insufficient
2. each required section must contain at least one valid depth unit
3. each `key_detail_id` in `depth_inputs.key_detail_trace` must be mapped into summary or notes

Failure mapping:

1. missing required section unit -> `notes_too_shallow`
2. unmapped key detail trace -> `notes_too_shallow`
3. claim without support link/snippet -> `notes_too_shallow`

## Required Sections by Source Type (`depth_inputs.required_sections`)

Use this contract during Stage B overlay:

1. Repo: `문제정의`, `구조/메커니즘`, `실행/운영`, `적용`, `리스크`
2. Article (`article_profile: narrative`): `주장`, `작동 원리`, `사례/근거`, `적용`, `한계`
3. Article (`article_profile: docs_reference`): `문서 성격과 범위`, `기능 구조`, `구현 시 확인할 근거`, `적용`, `한계`
4. Scrap: `관측 사실`, `해석 경계`, `적용 포인트`, `주의`
5. Paper: keep existing mandatory paper evidence reflection + claim-support mapping

## Summary Writing Rule (easy-kr-v1)

The `> [!summary]` block must be assembled from Evidence Pack `## Summary Kit`.

Required elements (existence-only; no fixed counts):

* Hook/intro line (optional but recommended if it increases clarity)
* `one_liner` must appear
* `why_it_matters` must appear
* `key_details` should be reflected as scannable items (bullets or numbering are allowed when natural)
* `use_when/avoid_when` should appear when evidence exists
* `quickstart` should appear when evidence exists
* `gotchas` should appear when evidence exists

Hard rules:

1. Do not force a fixed number of bullets or “Top 5”.
2. Do not add ungrounded claims; if something is uncertain, label as unknown/missing rather than invent.
3. Avoid redundant points; merge duplicates.
4. Volatile metrics (stars, etc.) only if evidenced.
5. Prefer Markdown bullet/numbered lists for scannability when clarity improves.

## Type-Specific Writing Contract

### Article

Profile-aware writing:

1. `article_profile: narrative` (default when not provided):
  * Cover with source-grounded detail:
    * What / Why
    * key claims and mechanisms
    * evidence-backed details and examples
    * assumptions and constraints
    * practical application and cautions
  * Depth overlay labels:
    * `주장`
    * `작동 원리`
    * `사례/근거`
    * `적용`
    * `한계`
2. `article_profile: docs_reference`:
  * Treat the note as docs/reference digest, not argumentative prose.
  * Prefer section intent:
    * `문서 성격과 범위`
    * `기능 구조`
    * `구현 시 확인할 근거`
    * `적용`
    * `한계`
  * Avoid forcing “주장” wording when source is a neutral reference doc.

### Repo

Cover with source-grounded detail:

* purpose and differentiator
* structure and key modules (when visible)
* installation and execution (when available)
* extension points (when available)
* maintenance/production signals (when available)
* operational cautions

Depth overlay requirement:

* ensure required section labels are all covered:
  * `문제정의`
  * `구조/메커니즘`
  * `실행/운영`
  * `적용`
  * `리스크`

### Scrap

Cover with source-grounded detail:

* OCR literal content
* context
* explicit claims vs inference vs unknowns

Depth overlay requirement:

* ensure required section labels are all covered:
  * `관측 사실`
  * `해석 경계`
  * `적용 포인트`
  * `주의`

### Paper (Evidence Reflection Mandatory)

Inside `## ❗️ Notes`, reflect these evidence items when present:

* `contributions`
* `method_overview` and `key_components`
* experimental setup summary
* `main_results` with original numeric comparisons and locators
* `limitations` and `assumptions`
* `claim_cards` mapped as `claim -> support locator`

Title rule for Paper:

* do not include arXiv-id token like `[2510.12345]`

## Shallow-Content Prohibition

Do not use fixed-count quotas.
Judge depth by evidence coverage completeness.

Fail with `notes_too_shallow` when:

1. core evidence claims are omitted
2. key conditions or constraints are omitted
3. key results or figure evidence is omitted when available
4. text is generic and not traceable to evidence
5. Summary Kit exists but is not materially reflected in summary/notes
6. any required section is present but has no valid depth unit
7. any `key_detail_id` in `depth_inputs.key_detail_trace` is unmapped
8. claim statements are not backed by `support_locator` or `evidence_snippet`

## Figure Insertion Rule

Insert figure only when all are true:

1. figure passed extract quality gate
2. metadata exists (`figure_id`, `page` if relevant, `caption`, `why_meaningful`, `selection_reason`)
3. figure materially improves explanation

Fail with:

* `figure_not_meaningful`
* `figure_metadata_missing`

## MoC and Reference Rules

MoC section:

1. add only links already existing in vault
2. when no candidates exist, write exact fallback bullet: `- 아직 연결된 MoC 없음`
3. keep MoC as Markdown bullet list only; do not emit pseudo-YAML keys (for example `unresolved_links:`)

Reference section:

1. add only supplementary links not present in `# Original Content`
2. do not copy original-content links
3. do not add local asset paths

## Completion Rule

On success:

1. pass internal YAML parse self-check
2. pass source-grounded depth self-check (including Summary Kit reflection)
3. pass immutable-zone and exact-equal link self-check
4. write integrity metadata to done pack:

```text
original_content_hash_sha256: <sha256 hex>
original_content_url_list:
  - <link_item1>
  - <link_item2>
original_content_source: existing|generated
original_content_line_count: <integer>
```

Depth completion metadata (required):

```text
depth_result: pass|fail
depth_missing_units:
  - <section_or_unit_id>
```

5. move pack from pending to `/Users/joshua/Library/Mobile Documents/iCloud~md~obsidian/Documents/joshua/99-meta/draft/done`
6. preserve draft filename `[yymmdd] <title>_draft.md`
7. normalize invalid suffix to exactly one `_draft` before finalize
8. return required `note_path` and `done_pack_path`

## Failure Behavior

On failure:

1. do not move pack to done
2. do not finalize partial body rewrite
3. return explicit reason code

Recommended reason codes (existing):

* `yaml_parse_error`
* `title_not_quoted`
* `category_not_30_resource`
* `tags_not_yaml_list`
* `link_not_yaml_list`
* `tags_invalid_format`
* `paper_title_contains_arxiv_id`
* `notes_too_shallow`
* `figure_not_meaningful`
* `figure_metadata_missing`
* `original_content_missing`
* `original_content_contains_wikilink`
* `original_content_modified`
* `link_not_equal_original_content`
* `link_contains_non_url`
* `moc_invalid_shape`
* `key_detail_id_exposed`

## Idempotency

1. rerun refreshes managed sections without duplication
2. preserve unrelated user content when safely separable
3. preserve immutable zone bytes exactly on rerun

## Style Exemplars (Few-shot) — easy-kr-v1

Rules:

* Exemplars are for tone/structure only.
* Do not copy facts/numbers from exemplars.
* Write content must be grounded in Summary Kit + Evidence.
* Emoji optional.
* Keep exemplar body text unchanged; enforce depth via Stage B overlay and QA only.

### Repo Exemplar (Structure/Tone Reference Only)

웹의 모든 데이터를 LLM이 가장 소화하기 쉬운 형태로 완벽하게 떠먹여 주는 괴물 같은 오픈소스를 소개합니다!

깃허브 스타만 벌써 5만 개를 돌파했네요. 🤯
우리가 흔히 알던 기존의 웹 스크래퍼들은 철저히 '사람'이 읽기 편하도록 데이터를 추출했죠.
하지만 오늘 소개해 드릴 Crawl4AI는 오직 'LLM'을 위해 탄생한 특별한 스크래퍼입니다.
RAG 파이프라인이나 AI 에이전트를 구축해 보신 분들은 아실 거예요.
웹 데이터를 긁어와서 AI가 이해할 수 있게 전처리하는 과정이 얼마나 고통스러운지 말이죠. 🥲
이 툴은 그 번거로운 과정을 완벽하게 해결해 줍니다.
💡 핵심 포인트는 다음과 같습니다.

• LLM 맞춤형 출력: 수집된 데이터를 RAG나 에이전트 워크플로우에 즉시 투입할 수 있도록 아주 깔끔한 Markdown 형태로 뽑아줍니다.
• 지능형 필터링: OpenAI, DeepSeek, Ollama 등과 연동해서, 내가 던진 질문과 관련된 '진짜 필요한 데이터'만 쏙쏙 걸러냅니다.
• 강력한 수집력: 봇 방지 사이트도 거뜬히 통과하는 스텔스 모드, 복잡한 병렬 크롤링 지원은 물론, 크래시 복구 기능까지 갖췄습니다.
• 뛰어난 확장성: PDF 텍스트 추출부터 REST API, WebSocket 스트리밍까지 실무 프로덕션 환경에 필요한 기능이 꽉 꽉 채워져 있습니다.

이 모든 기능이 100% 오픈소스(Apache 2.0)로 무료 제공됩니다!
AI 서비스를 개발하시거나 스터디하시는 분들이라면 꼭 한 번 적용해 보시길 추천해 드려요.
🚀 자세한 소스 코드와 공식 문서는 아래 깃허브 링크에서 확인하실 수 있습니다.

### Paper Exemplar (Structure/Tone Reference Only)

엔비디아(NVIDIA)에서 쌩쌩 돌아가는 AI 모델 코드, AMD로 툴 써서 변환하면 왜 제 성능이 안 나올까요? 🤯

그 충격적인 이유가 하드웨어 가장 밑바닥, 명령어(ISA) 수준에 숨어있습니다.

두 칩은 AI 시대의 양대 산맥이지만, 설계 철학부터가 완전히 다릅니다.

겉보기엔 비슷한 GPU 같지만 속을 들여다보면 이런 엄청난 차이들이 있어요. 🔍👇

• 1. 명령어의 디테일과 스케줄링 ⏱️
NVIDIA는 명령어 안에 '몇 사이클 쉼지' 같은 세밀한 스케줄링 정보가 꽉꽉 담겨있습니다(128비트).

반면 AMD는 명령어 자체는 가볍고(32/64비트), 컴파일러가 중간중간 '메모리 작업 끝날 때까지 기다려!
(S_WAITCNT)'라고 명시적으로 지시하는 방식입니다.

• 2. 이름만 똑같은 'FP8'의 배신 ⚠️
이게 제일 소름 돋는 포인트인데요!
둘 다 FP8 포맷을 쓴다고 하지만 스펙이 다릅니다.

NVIDIA(Hopper)에서 양자화한 모델을 AMD(MI300)에 그대로 올리면 완전 쓰레기 값이 나와버립니다.
같은 8비트 패턴이라도 해석하는 방식(지수 편향 등)이 완전히 다르거든요.

• 3. 데이터를 담는 그릇, 레지스터 📦
NVIDIA는 스레드당 256개의 레지스터를 통째로 씁니다.
하지만 AMD는 이걸 3가지(VGPR, SGPR, AGPR) 용도로 쪼개놨어요.

변수마다 어느 그릇에 담을지 컴파일러가 빡세게 분류해야 하고, 그릇 간에 데이터를 옮길 때도 비용이 발생합니다.

• 4. 꽁꽁 숨긴 영업기밀 vs 100% 오픈소스 🔒
NVIDIA의 컴파일러(ptxas)는 영업기밀입니다.

내부에서 어떻게 코드를 최적화하는지 개발자가 알 길이 없죠.
반면 AMD는 오픈소스(LLVM)라 모든 최적화 과정을 투명하게 뜯어볼 수 있습니다.

결론적으로, 단순히 코드 문법만 바꿔주는 툴(hipify)로는 100% 성능을 낼 수 없습니다.

진짜 성능 차이는 코드가 아니라 '128비트 명령어 구조'와 '레지스터의 배치' 같은 하드웨어의 뼈대에서 나오니까요.
진정한 최적화의 길은 정말 멀고도 험하네요! 💻✨

AI 하드웨어 최적화나 MLOps에 관심 있으신 분들이라면 꼭 한 번쯤 고민해 볼 만한 재밌는 인사이트인 것 같습니다.

### Article Exemplar (Structure/Tone Reference Only)

LLM 에이전트의 진짜 한계를 깨고 싶다면, 어제 공개된 'GLM-5' 기술 보고서는 무조건 읽어보셔야 합니다. 🤯

단순한 모델 발표가 아니라, 제대로 된 Agentic LLM을 구축하기 위한
'역대급 설계도'가 통째로 풀렸거든요.

Maxime Labonne가 분석한 내용 중 가장 소름 돋는 핵심 디테일 5가지를 요약해 드릴게요!

<첨부 사진이 논문 대표 사진으로 선택됨>

1 어텐션 연산량 반토막 내기 ✂️
DeepSeek의 DSA(Sparse Attention)를 MLA 위에 얹었습니다.
긴 문맥을 잃지 않으면서도 토큰 단위의 희소성을 확보해 어텐션 연산량을 무려 1.5~2배나 줄여냈어요.
(2/8)

2 데이터 퀄리티의 끝판왕 📚
DCLM 분류기에 더해, 위키피디아 기반의 'World Knowledge 분류기'까지 도입했습니다.
저품질 데이터 속에서도 훌륭한 지식만 알짜배기로 추출하고, 고유 코드 토큰도 28%나 늘렸습니다.

3 3가지 '생각' 모드 (Thinking modes) 🧠
에이전트에게 3가지 생각 방식을 부여했습니다.
• Interleaved: 매 턴/도구 사용 전마다 생각하기
• Preserved: 이전 턴의 '생각'을 기억해 중복 추론 방지
• Turn-level: 지연 시간(Latency)을 고려해 턴 단위로

ON/OFF
(심지어 에이전트의 실수 궤적까지 학습시켜 스스로 오류를 수정하게 만들었다고 해요!)

4 초대규모 비동기 RL ⚡
1,000개 이상의 롤아웃을 동시에 처리합니다.
GPU의 추론과 학습을 완벽하게 분리하고, 오래된 샘플은 과감히 버리는 방식으로 오프폴리시(Off-policy) 문제를 해결했어요.

5 망각 방지 기술의 새로운 접근 🛡️
보통 모델 병합을 많이 쓰는데, GLM-5는 RL 단계마다 SFT 등의 체크포인트를 선생님(Teacher)으로 삼아 지식을 잃어버리지 않게 증류(Distillation)하는 방식을 택했습니다.

포스트 트레이닝(Post-training) 파이프라인을 깎고 계신 분들에게는 진짜 보물창고 같은 리포트네요.

개인적으로는 망각 방지를 위한 새로운 접근법이 참 흥미로운데,
여러분은 이 중에서 어떤 기술이 가장 눈에 띄시나요? 👀

### Anti-example (Do NOT do this)

* “이 툴은 정말 최고고 완벽합니다. 모든 문제를 해결합니다.” (근거 없음)
* “핵심 5가지!” (근거 없이 숫자 강제)
* Quickstart가 원문에 있는데도 빠진 추상 요약

