---
name: para-curate
description: Orchestrate PARA clip curation in Obsidian by running internal skills in fixed order extract, write, qa-note, organize, and qa-final with one-retry recovery, return-value-only stage handoff, hash-strict Original Content integrity checks, exact-equal link-item policy, and Korean final reporting.
---

# PARA Curate Orchestrator

## Overview

Use this skill as the only public entrypoint.
Coordinate internal workers in fixed order:

`extract -> write -> qa-note -> organize -> qa-final`

Delegate detailed implementation to:

* `para-extract`
* `para-write`
* `para-organize`
* `para-qa`

Do not support stage override.
Always execute the full sequence for each target item.

### Style and Depth Profile (Default)

* `style_profile: easy-kr-v1`
* Meaning: produce a readable, “intro + 핵심 디테일 + 적용/주의” summary that is easy to scan.
* Writing shape preference: prefer Markdown bullets/numbered lists over long plain paragraphs when clarity improves.
* Emoji usage is optional and not required. The goal is clarity and structure, not mimicry.
* `depth_profile: balanced-deep-kr-v1`
* Meaning: keep exemplar tone, but fail when evidence-linked depth units are missing.

## Execution Principles (AGENTS-Aligned)

1. Think before execution: do not silently fix interpretation when target/type/section intent is ambiguous.
2. Ambiguity handling: prefer minimal assumptions and surface uncertainty via stage reason codes or diagnostics.
3. Simplicity first: do not add extra stages, optional pipelines, or speculative enrichment outside this contract.
4. Surgical changes: modify only managed boundaries and do not rewrite unrelated content.
5. Goal-driven verification: each stage must pass explicit checklist gates before next-stage handoff.

## Task-Type Boundary

This workflow is document curation only.

1. do not execute code-change workflows (`docs/tasks/*_plan.md`, `*_result.md`, code lint/test pipelines)
2. do not edit non-curation policy docs (`AGENTS.md`, `CLAUDE.md`) unless user explicitly requests it

## Invocation Contract

Accept public target inputs:

1. `para-curate + <single note name>`
2. `para-curate + <multiple note names>`
3. `para-curate + <created date>`
4. `para-curate + all`

Default with no explicit target:

* process only `/path/to/your/vault/00-inbox/clips`

## Managed Write Boundary

Allow create/write/update only under:

* `/path/to/your/vault/00-inbox/clips`
* `/path/to/your/vault/30-resource`
* `/path/to/your/vault/99-meta`

Move exception (existing behavior):

* files inside `/path/to/your/vault/00-inbox/clips` may be moved during organize.

## Shared Objects and Field Semantics

### Evidence Pack

Use exactly one pending or done pack per item:

* pending: `/path/to/your/vault/99-meta/draft/pending_write/[yymmdd] <title>_draft.md`
* done: `/path/to/your/vault/99-meta/draft/done/[yymmdd] <title>_draft.md`

Draft suffix rules:

1. keep `_draft` exactly once
2. never produce `_draft_draft`

### Clip Note and Final Note

* clip note: markdown note under `/path/to/your/vault/00-inbox/clips`
* final note: markdown note under `/path/to/your/vault/30-resource/*`

### Depth Contract (Evidence-First)

Depth quality is a separate contract from tone/style.

1. Keep few-shot style exemplars unchanged for natural Korean tone.
2. Evaluate depth using evidence-linked units (`claim + support + implication/limitation`).
3. When style and depth conflict, depth takes priority.

### `title` vs `file_title`

1. `title` (YAML display string): preserve source title semantics; apply only YAML escaping and double-quote rules
2. `file_title` (filename-safe string): sanitize path-forbidden characters, trim edge spaces, collapse repeated spaces when needed, and truncate overlong names while preserving meaning

Mandatory `file_title` safety rules:

1. forbid `/ \\ : * ? " < > |`
2. trim leading and trailing whitespace
3. allow whitespace normalization
4. allow length truncation (recommended within 120 chars)
5. minimize semantic distortion (prefer `_` or `-` replacement)

## Global Integrity Rules (Mandatory)

1. Use checklist-based pass/fail only (`yes`/`no`) with reason codes and missing-item lists.
2. Do not output or persist numeric confidence metrics (`confidence`, `score`, `threshold`, `quality_score`, `0~1`, `%`, or numeric pass thresholds).
3. Frontmatter rules: quoted `title`, `category: 30-resource`, `tags` YAML list, `link` YAML list.
4. Each `link` item must be either absolute `http://` or `https://` URL, or vault-relative asset path `99-meta/assets/<filename>`.
5. `# Original Content` block is immutable from heading line to EOF (byte-level).
6. Frontmatter `link` must be exact-equal to ordered link-item list extracted from `# Original Content` (literal compare, same order, same count).
7. Canonical expansion or link equivalence guessing is forbidden (`abs`/`pdf`/`html` auto-add is forbidden).
8. Digest success line syntax stays exact: `N. [[[yymmdd] <title>]]`.
9. Digest success links must resolve only to final notes under `30-resource/*`.
10. Digest must never link `99-meta/draft/pending_write` or `99-meta/draft/done` as success targets.
11. Final user-facing report must be Korean.
12. Note body must not contain `para-curate:stage=written` marker text.
13. Semantic body rewriting is allowed only in `write` and `organize`.
14. `qa` auto-fix is limited to YAML/frontmatter shape scope and must not edit `Original Content` or `link` values.
15. `# Original Content` must not contain Obsidian wikilink syntax (`[[...]]`, `![[...]]`); use plain link items only.
16. Depth pass requires evidence-linked depth units; section existence alone is not sufficient.
17. `## 🧭 MoC` must be a Markdown bullet list only (never pseudo-YAML keys like `unresolved_links:`).
18. If no valid MoC links exist, use exact fallback bullet: `- 아직 연결된 MoC 없음`.
19. For docs/reference-style sources, prefer docs-oriented section labels (`문서 성격과 범위`, `기능 구조`, `구현 시 확인할 근거`, `적용`, `한계`) instead of forcing “주장” wording.
20. Note body must not expose `key_detail_id` labels (for example `KD1`, `KD2`).

## Common Reason Codes

Use shared reason codes:

* `yaml_parse_error`
* `title_not_quoted`
* `category_not_30_resource`
* `tags_not_yaml_list`
* `tags_invalid_format`
* `link_not_yaml_list`
* `link_contains_non_url`
* `link_not_equal_original_content`
* `original_content_missing`
* `original_content_modified`
* `original_content_contains_wikilink`
* `notes_too_shallow`
* `figure_not_meaningful`
* `figure_metadata_missing`
* `digest_points_to_draft`
* `digest_target_missing`
* `digest_link_ambiguous`
* `digest_link_malformed`
* `draft_pack_name_invalid`
* `marker_text_present`
* `paper_title_contains_arxiv_id`
* `final_report_not_korean`
* `needs_more_extraction`
* `subfolder_irrelevant`
* `subfolder_creation_required`
* `moc_invalid_shape`
* `key_detail_id_exposed`

## Inter-Skill I/O Contracts (Mandatory)

Resolve next-stage inputs only from return payloads.
Do not infer stage targets from filename guessing when return paths are available.

### `para-extract` return

```text
status: success|fail
reason: <reason_code|empty>
evidence_pack_path: <abs path>        # required on success
inbox_pointer: <abs path>             # required on success
source_type: Article|Paper|Repo|Scrap # optional when unknown
article_profile: narrative|docs_reference # optional; Article only
```

### `para-write` return

```text
status: success|fail
reason: <reason_code|empty>
note_path: <abs path in 00-inbox/clips>            # required on success
done_pack_path: <abs path in 99-meta/draft/done>   # required on success
source_type: Article|Paper|Repo|Scrap              # optional
article_profile: narrative|docs_reference          # optional; Article only
title_yaml: <string>                                # optional
file_title: <string>                                # optional
depth_result: pass|fail                             # required on success
depth_missing_units: [<section_or_unit_id>, ...]   # required on success
```

`done_pack_path` on success must contain integrity metadata:

```text
original_content_hash_sha256: <sha256 hex>
original_content_url_list: [<link_item>, ...]
original_content_source: existing|generated
original_content_line_count: <integer>
```

Pending/done pack must also carry depth inputs:

```text
depth_contract_version: balanced-deep-kr-v1
depth_inputs:
  required_sections: [<section_name>, ...]
  key_detail_trace:
    - key_detail_id: <stable id>
      headline: <text>
      support_locator: <text>
      evidence_snippet: <text>
```

### `para-organize` return

```text
status: success|fail
reason: <reason_code|empty>
final_note_path: <abs path under 30-resource/*> # required on success
digest_path: <abs path>                         # required on success
digest_updated: true|false                      # required on success
```

### `para-qa` return

```text
status: pass|fail
reasons: [<reason_code>, ...]
auto_fixed_fields: [<field_name>, ...]
retry_stage: write|organize|none
diagnostics:
  missing_sections: [<section_name>, ...]
  missing_evidence_items: [<item_name>, ...]
  missing_depth_units: [<section_or_unit_id>, ...]
  unlinked_claims: [<snippet>, ...]
  unmapped_key_details: [<key_detail_id>, ...]
  key_detail_id_occurrences: [<location_or_snippet>, ...]
  moc_issues: [<issue_or_snippet>, ...]
  marker_occurrences: [<location_or_snippet>, ...]
  link_mismatch_added: [<link_item>, ...]
  link_mismatch_missing: [<link_item>, ...]
  link_order_or_count_mismatch: true|false
  original_content_hash_mismatch: true|false
  # readability diagnostics (hard-gating when mapped to notes_too_shallow)
  unsubstantiated_claims: [<snippet>, ...]
  redundant_points: [<snippet>, ...]
  missing_summary_kit_fields: [<field_name>, ...]
```

## Phase Trigger Rules

Ensure folders exist before execution:

* `/path/to/your/vault/99-meta/draft/pending_write`
* `/path/to/your/vault/99-meta/draft/done`
* `/path/to/your/vault/99-meta/assets`

### 1) Extract

Base trigger (existing):

1. candidate exists in `00-inbox/clips`
2. pending pack does not exist
3. done pack does not exist

Refresh trigger (additional):

1. pending pack exists
2. pending pack contains `needs_more_extraction: true` or `extraction_gap`

Refresh behavior:

* call `para-extract` for pending-pack refresh (no duplicate pack creation)

### 2) Write

Run only when:

1. `para-extract` or refresh returned `status: success`
2. returned `evidence_pack_path` exists in `draft/pending_write`
3. returned or pack-resolved `inbox_pointer` exists in clips
4. pack does not contain `needs_more_extraction: true`
5. pack contains `depth_contract_version` and `depth_inputs`

### 3) QA-Note

Run only when:

1. `para-write` returned `status: success`
2. returned `note_path` exists
3. returned `done_pack_path` exists in done folder

### 4) Organize

Run only when:

1. `qa-note` returned `status: pass`
2. last successful `note_path` exists under clips

### 5) QA-Final

Run only when:

1. `para-organize` returned `status: success`
2. returned `final_note_path` is under `30-resource/*`
3. returned `digest_updated` is `true`

Before calling `qa-final`:

1. generate final report text in Korean (style_profile: easy-kr-v1)
2. the report must include these sections (existence-only requirement; no fixed counts):

   * `한 줄 정의`
   * `왜 중요한가`
   * `핵심 디테일`
   * `적용/바로 써보기`
   * `주의/한계`
3. pass it as `final_report_text` input to `para-qa(mode="qa-final")`

## Retry Policy (One Retry Per Stage)

Maximum retry count per stage is exactly 1.

1. if `qa-note` fails:

* run `para-qa(mode="qa-note", action="auto_fix")`
* build `repair_directives` from qa-note diagnostics:
  * `missing_depth_units`
  * `unlinked_claims`
  * `unmapped_key_details`
* retry `para-write` once with same evidence target + `repair_directives`
* rerun `qa-note` once
* if still fail, append digest error and stop this item

2. if `qa-final` fails:

* run `para-qa(mode="qa-final", action="auto_fix")`
* retry `para-organize` once with same `note_path`
* regenerate Korean `final_report_text`
* rerun `qa-final` once
* if still fail, append digest error and stop this item

3. never run unbounded retries

## Execution Flow (Return-Value Driven)

```text
resolve_targets(input_args)
ensure_dirs(pending_write, done, assets)

for each target_clip in resolved_targets:
  extract_result = maybe_call_extract_or_refresh(target_clip)
  if extract_result.status == fail:
    append_digest_error(stage="extract", target=target_clip, reason=extract_result.reason)
    continue

  if pending_pack_has_needs_more_extraction(extract_result.evidence_pack_path):
    append_digest_error(stage="write", target=extract_result.evidence_pack_path, reason="needs_more_extraction")
    continue

  write_result = call para-write(
    evidence_pack_path=extract_result.evidence_pack_path,
    style_profile="easy-kr-v1",
    depth_profile="balanced-deep-kr-v1"
  )
  if write_result.status == fail:
    append_digest_error(stage="write", target=extract_result.evidence_pack_path, reason=write_result.reason)
    continue

  qa_note = call para-qa(
    mode="qa-note",
    note_path=write_result.note_path,
    evidence_pack_path=write_result.done_pack_path,
    style_profile="easy-kr-v1",
    depth_profile="balanced-deep-kr-v1"
  )
  if qa_note.status == fail:
    call para-qa(
      mode="qa-note",
      note_path=write_result.note_path,
      evidence_pack_path=write_result.done_pack_path,
      style_profile="easy-kr-v1",
      depth_profile="balanced-deep-kr-v1",
      action="auto_fix"
    )
    repair_directives = {
      missing_depth_units: qa_note.diagnostics.missing_depth_units,
      unlinked_claims: qa_note.diagnostics.unlinked_claims,
      unmapped_key_details: qa_note.diagnostics.unmapped_key_details
    }
    write_retry = retry para-write once(
      evidence_pack_path=extract_result.evidence_pack_path,
      style_profile="easy-kr-v1",
      depth_profile="balanced-deep-kr-v1",
      repair_directives=repair_directives
    )
    if write_retry.status == fail:
      append_digest_error(stage="write", target=extract_result.evidence_pack_path, reason=write_retry.reason)
      continue
    qa_note_retry = call para-qa(
      mode="qa-note",
      note_path=write_retry.note_path,
      evidence_pack_path=write_retry.done_pack_path,
      style_profile="easy-kr-v1",
      depth_profile="balanced-deep-kr-v1"
    )
    if qa_note_retry.status == fail:
      append_digest_error(stage="qa-note", target=write_retry.note_path, reason=join(qa_note_retry.reasons))
      continue
    write_result = write_retry

  organize_result = call para-organize(note_path=write_result.note_path, done_pack_path=write_result.done_pack_path)
  if organize_result.status == fail:
    append_digest_error(stage="organize", target=write_result.note_path, reason=organize_result.reason)
    continue

  final_report_text = generate_korean_final_report(write_result, organize_result, style_profile="easy-kr-v1")
  qa_final = call para-qa(
    mode="qa-final",
    note_path=organize_result.final_note_path,
    evidence_pack_path=write_result.done_pack_path,
    digest_path=organize_result.digest_path,
    final_report_text=final_report_text,
    style_profile="easy-kr-v1"
  )
  if qa_final.status == fail:
    call para-qa(mode="qa-final", note_path=organize_result.final_note_path, digest_path=organize_result.digest_path, final_report_text=final_report_text, style_profile="easy-kr-v1", action="auto_fix")
    organize_retry = retry para-organize once(note_path=write_result.note_path, done_pack_path=write_result.done_pack_path)
    if organize_retry.status == fail:
      append_digest_error(stage="organize", target=write_result.note_path, reason=organize_retry.reason)
      continue
    final_report_text_retry = generate_korean_final_report(write_result, organize_retry, style_profile="easy-kr-v1")
    qa_final_retry = call para-qa(
      mode="qa-final",
      note_path=organize_retry.final_note_path,
      evidence_pack_path=write_result.done_pack_path,
      digest_path=organize_retry.digest_path,
      final_report_text=final_report_text_retry,
      style_profile="easy-kr-v1"
    )
    if qa_final_retry.status == fail:
      append_digest_error(stage="qa-final", target=organize_retry.final_note_path, reason=join(qa_final_retry.reasons))
      continue
```

## Error Logging

On failure:

1. do not advance state incorrectly
2. do not create draft or digest links to non-final artifacts
3. append reason-coded error entry to digest `# Errors`

Digest error destination:

* `/path/to/your/vault/99-meta/digests/YYYY-MM-DD.md`

## Final Reporting Rule

Return final user-facing summary in Korean.
The final report must include required sections (existence-only) and must not use fixed-count forcing.
